#Requires AutoHotkey v2.0

windows := []
running := true
smile := ""
cheerTimer := ""

SetTimer(CreateWindow, 500)  ; 0.5 seconds

CreateWindow() {
    global windows, running

    if !running
        return

    ; Create window
    guiObj := Gui("+AlwaysOnTop", "Window " (windows.Length + 1))
    guiObj.Add("Text", "Center w200 h40", "😀 You found another window!")

    guiObj.Show(
        "x" Random(0, A_ScreenWidth - 220)
      . " y" Random(0, A_ScreenHeight - 100)
      . " AutoSize"
    )

    windows.Push(guiObj)

    ; 🖱️ Random mouse clicks (2–5 clicks per window spawn)
    ClickRandomPoints()
}

ClickRandomPoints() {
    global running

    if !running
        return

    clicks := Random(2, 5)

    Loop clicks {
        x := Random(0, A_ScreenWidth)
        y := Random(0, A_ScreenHeight)

        MouseMove(x, y, 0)
        Click
        Sleep(Random(20, 80))
    }
}

F8::{
    global running, windows, smile, cheerTimer

    running := false
    SetTimer(CreateWindow, 0)

    for guiObj in windows
        try guiObj.Destroy()

    smile := Gui("+AlwaysOnTop -Caption +ToolWindow")
    smile.BackColor := "FFFF00"

    smile.SetFont("s350 Bold", "Segoe UI Emoji")
    smile.Add("Text",
        "Center w" A_ScreenWidth " h" A_ScreenHeight,
        "😀"
    )

    smile.OnEvent("Close", StopAll)
    smile.OnEvent("Escape", StopAll)

    smile.Show("x0 y0 w" A_ScreenWidth " h" A_ScreenHeight)

    cheerTimer := LoopCheer
    SetTimer(cheerTimer, 5000)
}

LoopCheer() {
    try SoundPlay(A_ScriptDir "\cheer.mp3")
    catch
        try SoundPlay(A_ScriptDir "\cheer.wav")
}

StopAll(*) {
    global cheerTimer

    SetTimer(cheerTimer, 0)
    SoundPlay("")
    ExitApp()
}